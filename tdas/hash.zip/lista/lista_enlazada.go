package lista

type listaEnlazada[T any] struct {
	inicio *nodoLista[T]
	fin    *nodoLista[T]
	largo  int
}

type iterador[T any] struct {
	anterior *nodoLista[T]
	actual   *nodoLista[T]
	lista    *listaEnlazada[T]
}

type nodoLista[T any] struct {
	dato      T
	siguiente *nodoLista[T]
}

func crearNodo[T any](dato T, siguiente *nodoLista[T]) *nodoLista[T] {
	return &nodoLista[T]{dato: dato, siguiente: siguiente}
}

func CrearListaEnlazada[T any]() Lista[T] {
	return &listaEnlazada[T]{}
}

func (l *listaEnlazada[T]) EstaVacia() bool {
	return l.inicio == nil
}

func (l *listaEnlazada[T]) panicSiListaVacia() {
	if l.largo == 0 {
		panic("La lista esta vacia")
	}
}

func (l *listaEnlazada[T]) InsertarPrimero(valor T) {
	nuevo_nodo := crearNodo(valor, l.inicio)
	if l.EstaVacia() {
		l.fin = nuevo_nodo
	}
	l.inicio = nuevo_nodo
	l.largo++

}

func (l *listaEnlazada[T]) InsertarUltimo(valor T) {
	nuevo_nodo := crearNodo(valor, nil)
	if l.EstaVacia() {
		l.inicio = nuevo_nodo
	} else {
		l.fin.siguiente = nuevo_nodo
	}
	l.fin = nuevo_nodo
	l.largo++
}

func (l *listaEnlazada[T]) BorrarPrimero() T {
	l.panicSiListaVacia()
	valor := l.inicio.dato
	l.inicio = l.inicio.siguiente
	if l.largo == 1 {
		l.fin = nil
	}
	l.largo--
	return valor

}

func (l *listaEnlazada[T]) VerPrimero() T {
	l.panicSiListaVacia()
	return l.inicio.dato
}

func (l *listaEnlazada[T]) VerUltimo() T {
	l.panicSiListaVacia()
	return l.fin.dato

}

func (l *listaEnlazada[T]) Largo() int {
	return l.largo
}

func (l *listaEnlazada[T]) Iterar(visitar func(T) bool) {
	actual := l.inicio
	for actual != nil && visitar(actual.dato) {
		actual = actual.siguiente
	}
}

//Iterador

func (i *iterador[T]) panicSiFinIteracion() {
	if i.actual == nil {
		panic("El iterador termino de iterar")
	}
}

func (l *listaEnlazada[T]) Iterador() IteradorLista[T] {
	return &iterador[T]{
		anterior: nil,
		actual:   l.inicio,
		lista:    l,
	}
}

func (i *iterador[T]) VerActual() T {
	i.panicSiFinIteracion()
	return i.actual.dato
}

func (i *iterador[T]) HaySiguiente() bool {
	return i.actual != nil
}

func (i *iterador[T]) Siguiente() {
	i.panicSiFinIteracion()
	i.anterior = i.actual
	i.actual = i.actual.siguiente
}

func (i *iterador[T]) Insertar(valor T) {
	nuevo_nodo := nodoLista[T]{
		dato:      valor,
		siguiente: i.actual,
	}
	if i.lista.fin == i.anterior {
		i.lista.fin = &nuevo_nodo
	}
	if i.lista.inicio != i.actual {
		i.anterior.siguiente = &nuevo_nodo
	} else {
		i.lista.inicio = &nuevo_nodo
	}
	i.actual = &nuevo_nodo
	i.lista.largo++
}

func (i *iterador[T]) Borrar() T {
	i.panicSiFinIteracion()
	if i.lista.fin == i.actual {
		i.lista.fin = i.anterior
	}
	if i.lista.inicio == i.actual {
		i.lista.inicio = i.actual.siguiente
	} else {
		i.anterior.siguiente = i.actual.siguiente
	}
	valor_eliminado := i.actual.dato
	i.actual = i.actual.siguiente
	i.lista.largo--
	return valor_eliminado
}
