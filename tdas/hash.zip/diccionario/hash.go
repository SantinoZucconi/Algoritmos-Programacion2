package diccionario

import (
	"fmt"
	"hash/fnv"
	TDALista "tdas/lista"
)

type hash[K comparable, V any] struct {
	lista          []TDALista.Lista[nodo[K, V]]
	cant_elementos int
	tamaño         int
}

type nodo[K comparable, V any] struct {
	clave K
	valor V
}

func hashed[K comparable](dato K, tamaño int) int {
	h := fnv.New32()
	_, _ = h.Write([]byte(fmt.Sprint(dato)))
	return int(h.Sum32()) % tamaño
}

func crearNodo[K comparable, V any](clave K, valor V) nodo[K, V] {
	return nodo[K, V]{clave, valor}
}

func crearListas[K comparable, V any](tamaño int) []TDALista.Lista[nodo[K, V]] {
	lista := make([]TDALista.Lista[nodo[K, V]], tamaño)
	for i := 0; i < tamaño; i++ {
		lista[i] = TDALista.CrearListaEnlazada[nodo[K, V]]()
	}
	return lista
}

func CrearHash[K comparable, V any]() Diccionario[K, V] {
	listas := crearListas[K, V](1)
	return &hash[K, V]{lista: listas, cant_elementos: 0, tamaño: 1}
}

func panicSiNoPertenece(hayClave bool) {
	if !hayClave {
		panic("La clave no pertenece al diccionario")
	}
}
func hallarOperar[K comparable, V any](clave K, i TDALista.IteradorLista[nodo[K, V]], f func() nodo[K, V]) (V, bool) {
	var v V
	encontrado := false
	for i.HaySiguiente() && !encontrado {
		if i.VerActual().clave == clave {
			v = f().valor
			encontrado = true
		} else {
			i.Siguiente()
		}

	}
	return v, encontrado
}

func redimensionarSiNecesario[K comparable, V any](d *hash[K, V]) {
	if d.cant_elementos == 2*d.tamaño || d.cant_elementos*2 == d.tamaño {
		lista_aux := crearListas[K, V](d.cant_elementos)
		d.tamaño = d.cant_elementos
		iterador := d.Iterador()
		for iterador.HaySiguiente() {
			clave, valor := iterador.VerActual()
			lista_aux[hashed[K](clave, d.tamaño)].InsertarUltimo(crearNodo[K, V](clave, valor))
			iterador.Siguiente()
		}
		d.lista = lista_aux
	}
}

func (d *hash[K, V]) Guardar(clave K, valor V) {
	i := d.lista[hashed[K](clave, d.tamaño)].Iterador()
	_, habiaClave := hallarOperar(clave, i, i.Borrar)
	d.lista[hashed[K](clave, d.tamaño)].InsertarUltimo(crearNodo[K, V](clave, valor))
	if !habiaClave {
		d.cant_elementos++
	}
	redimensionarSiNecesario(d)

}

func (d hash[K, V]) Pertenece(clave K) bool {
	tam := d.tamaño
	i := d.lista[hashed[K](clave, tam)].Iterador()
	_, hayClave := hallarOperar(clave, i, i.VerActual)
	return hayClave
}

func (d hash[K, V]) Obtener(clave K) V {
	i := d.lista[hashed[K](clave, d.tamaño)].Iterador()
	valor, hayClave := hallarOperar(clave, i, i.VerActual)
	panicSiNoPertenece(hayClave)
	return valor
}

func (d *hash[K, V]) Borrar(clave K) V {
	i := d.lista[hashed[K](clave, d.tamaño)].Iterador()
	valorBorrado, hayClave := hallarOperar(clave, i, i.Borrar)
	panicSiNoPertenece(hayClave)
	d.cant_elementos--
	redimensionarSiNecesario(d)
	return valorBorrado

}

func (d hash[K, V]) Cantidad() int {
	return d.cant_elementos
}

func (d hash[K, V]) Iterar(condicion func(clave K, dato V) bool) {
	posicion := 0
	seguirIterando := true
	for posicion < d.tamaño && seguirIterando {
		iter := d.lista[posicion].Iterador()
		for iter.HaySiguiente() && seguirIterando {
			seguirIterando = condicion(iter.VerActual().clave, iter.VerActual().valor)
			if seguirIterando {
				iter.Siguiente()
			}
		}
		posicion++
	}
}

//-------------- ITERADOR --------------------

type iteradorExterno[K comparable, V any] struct {
	hash           hash[K, V]
	iterador_lista TDALista.IteradorLista[nodo[K, V]]
	posicion       int
}

func (d hash[K, V]) Iterador() IterDiccionario[K, V] {
	return &iteradorExterno[K, V]{hash: d, iterador_lista: d.lista[0].Iterador(), posicion: 0}
}

func (i *iteradorExterno[K, V]) panicSiFinIteracion() {
	if !i.HaySiguiente() {
		panic("El iterador termino de iterar")
	}
}

func (i *iteradorExterno[K, V]) HaySiguiente() bool {
	if i.iterador_lista.HaySiguiente() {
		return true
	} else if i.posicion < len(i.hash.lista)-1 {
		i.posicion++
		i.iterador_lista = i.hash.lista[i.posicion].Iterador()
		return i.HaySiguiente()
	}
	return false
}

func (i *iteradorExterno[K, V]) Siguiente() {
	i.panicSiFinIteracion()
	i.iterador_lista.Siguiente()
}

func (i iteradorExterno[K, V]) VerActual() (K, V) {
	i.panicSiFinIteracion()
	return i.iterador_lista.VerActual().clave, i.iterador_lista.VerActual().valor
}
